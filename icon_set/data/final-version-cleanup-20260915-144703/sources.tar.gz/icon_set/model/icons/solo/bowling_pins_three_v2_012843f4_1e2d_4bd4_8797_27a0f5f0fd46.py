"""Three bowling pins with the central pin lower and wider. No useful local Lucide bowling match; shared heads and smoothly bulging bellies preserve all three pins. Source overlaps separated for clearance.

SOLO48 HRECT_L; live visible envelope (2, 6, 46, 42).
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '012843f4-1e2d-4bd4-8797-27a0f5f0fd46'
SOURCE_PATH = 'pictographic-primitives/symbol/three bowlings_012843f4-1e2d-4bd4-8797-27a0f5f0fd46.svg'
AUTHOR = 'gpt-6'

class BowlingPinsThreeVariant2(Solo48):
    icon_id = 'bowling-pins-three-v2'
    variant_of = 'bowling-pins-three'
    variant_label = 'Hole and centerline reconstruction'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'objects/symbols'
    aliases = ()
    keywords = ('bowling', 'pins', 'skittles', 'sport', 'game', 'alley', 'strike', 'leisure')

    def oval(self, n, cx, cy, rx, ry=None):
        ry = rx if ry is None else ry
        self.add_arc(n + '-top', (cx - rx, cy), (cx + rx, cy), radius_x=rx, radius_y=ry)
        self.add_arc(n + '-bottom', (cx + rx, cy), (cx - rx, cy), radius_x=rx, radius_y=ry)
        self.add_contour(n, n + '-top', n + '-bottom', closed=True)

    def raw(self, n, points):
        for j, (a, b) in enumerate(zip(points, points[1:]), 1):
            self.add_line(n + '-' + str(j), a, b)

    def path(self, n, points, closed=False):
        self.add_polyline(n, *points, closed=closed)

    def build(self):
        """Rebuild all three pins from one wider head and neck definition; equal16-unit spacing preserves4-unit ink gaps."""
        front = True
        for j, cx in enumerate((8, 24, 40)):
            n = 'pin-' + str(j)
            lower = front and j == 1
            y = 12 if lower else 8
            belly = 4
            base = 36 if front and (not lower) else 40
            rx = belly - 3
            self.add_arc(n + '-head', (cx - 4, y + 4), (cx + 4, y + 4), radius_x=4)
            self.add_line(n + '-neck-r', (cx + 4, y + 4), (cx + 3, 20))
            self.add_arc(n + '-upper-r', (cx + 3, 20), (cx + belly, 29), radius_x=rx, radius_y=9)
            self.add_arc(n + '-lower-r', (cx + belly, 29), (cx + 3, base), radius_x=rx, radius_y=base - 29)
            self.add_line(n + '-base', (cx + 3, base), (cx - 3, base))
            self.add_arc(n + '-lower-l', (cx - 3, base), (cx - belly, 29), radius_x=rx, radius_y=base - 29)
            self.add_arc(n + '-upper-l', (cx - belly, 29), (cx - 3, 20), radius_x=rx, radius_y=9)
            self.add_line(n + '-neck-l', (cx - 3, 20), (cx - 4, y + 4))
            self.add_contour(n, *[n + '-' + part for part in ('head', 'neck-r', 'upper-r', 'lower-r', 'base', 'lower-l', 'upper-l', 'neck-l')], closed=True)
