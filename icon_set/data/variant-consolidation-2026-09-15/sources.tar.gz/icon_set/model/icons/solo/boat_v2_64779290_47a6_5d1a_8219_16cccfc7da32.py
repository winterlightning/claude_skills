"""boat: next fifty AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '64779290-47a6-5d1a-8219-16cccfc7da32'
SOURCE_PATH = 'icons-json/transportation/boat_64779290-47a6-5d1a-8219-16cccfc7da32.json'
AUTHOR = 'gpt-6'

class BoatVariant2(Solo48):
    icon_id = 'boat-v2'
    variant_of = 'boat'
    variant_label = 'AI review · next 50'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'transportation'
    aliases = ()
    keywords = ('boat', 'transportation', 'solo-ai-next50')

    def build(self):
        # Plan: A side-view cabin cruiser retains the source sloping bow and rear cabin. A level gunwale and smooth bow use precise cabin attachments; deliberate travel direction.
        # Reference: Lucide ship original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('hull',(8,24),[('L',(16,24)),('L',(32,24)),('L',(36,24)),('L',(44,24)),('C',(32,40),(42,32),(38,40)),('L',(4,40)),('L',(8,24))],True)
        poly('cabin',(16,24),(20,8),(28,8),(36,24));join('cabin','hull')
