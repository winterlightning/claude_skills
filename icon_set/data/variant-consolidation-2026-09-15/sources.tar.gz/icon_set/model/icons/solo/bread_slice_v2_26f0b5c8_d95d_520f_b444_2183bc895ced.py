"""bread-slice: next fifty AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '26f0b5c8-d95d-520f-b444-2183bc895ced'
SOURCE_PATH = 'icons-json/food/bread slice_26f0b5c8-d95d-520f-b444-2183bc895ced.json'
AUTHOR = 'gpt-6'

class BreadSliceVariant2(Solo48):
    icon_id = 'bread-slice-v2'
    variant_of = 'bread-slice'
    variant_label = 'AI review · next 50'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'food'
    aliases = ()
    keywords = ('bread', 'slice', 'food', 'solo-ai-next50')

    def build(self):
        # Plan: A tall rounded toast slice has a smoothly arched top and four-unit lower corner radii. Its narrower body distinguishes it from the square sandwich slice.
        # Reference: Lucide sandwich original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('slice',(16,44),[('A',(12,40),4,4,True),('L',(12,20)),('C',(8,14),(10,18),(8,17)),('C',(24,4),(8,7),(16,4)),('C',(40,14),(32,4),(40,7)),('C',(36,20),(40,17),(38,18)),('L',(36,40)),('A',(32,44),4,4,True),('L',(16,44))],True)
