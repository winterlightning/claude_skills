"""brain-f98adc76: next fifty AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = 'f98adc76-41e4-410a-a9e9-a02974009658'
SOURCE_PATH = 'icons-json/artificial-intelligence/brain_f98adc76-41e4-410a-a9e9-a02974009658.json'
AUTHOR = 'gpt-6'

class BrainF98adc76Variant2(Solo48):
    icon_id = 'brain-f98adc76-v2'
    variant_of = 'brain-f98adc76'
    variant_label = 'AI review · next 50'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'artificial-intelligence'
    aliases = ()
    keywords = ('brain', 'artificial-intelligence', 'solo-ai-next50')

    def build(self):
        # Plan: A side-view brain has three broad lobes and two smooth folds. Its left and right folds differ intentionally to describe a lateral anatomical view.
        # Reference: Lucide brain original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('brain',(4,28),[('C',(10,16),(4,21),(6,17)),('C',(22,8),(10,8),(16,8)),('C',(34,12),(28,8),(32,8)),('C',(44,24),(42,12),(44,17)),('C',(34,40),(44,34),(40,40)),('C',(24,36),(29,40),(26,39)),('C',(12,38),(20,40),(15,40)),('C',(4,28),(6,38),(4,34))],True)
        path('fold-right',(34,12),[('C',(28,27),(29,13),(28,20))]);join('fold-right','brain')
        path('fold-left',(22,8),[('C',(16,22),(16,11),(16,17))]);join('fold-left','brain')
