"""casino-clover: Three heart-shaped leaves; earlier revisions preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '940923da-19e4-4b49-811d-53f2118f022d'
SOURCE_PATH = 'icons-json/entertainment/casino clover_940923da-19e4-4b49-811d-53f2118f022d.json'
AUTHOR = 'gpt-6'

class CasinoCloverVariant3(Solo48):
    icon_id = 'casino-clover-v3'
    variant_of = 'casino-clover-v2'
    variant_label = 'Three heart-shaped leaves'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'entertainment'
    aliases = ()
    keywords = ('solo-ai-shapes-refine', 'solo-ai-next100', 'casino-clover')

    def build(self):
        # Plan: Restore the three heart-shaped leaves and gently curved stem from the original, with balanced side leaves and smooth curves.
        # Reference: Lucide clover: original and atomic-debug geometry.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('clover',(24,30),[('C',(10,36),(17,35),(12,38)),('C',(6,30),(6,36),(6,33)),('C',(9,26),(6,28),(8,27)),('C',(6,21),(7,25),(6,23)),('C',(16,18),(6,15),(12,15)),('C',(15,11),(13,15),(13,13)),('C',(19,6),(15,8),(16,6)),('C',(24,9),(21,6),(23,7)),('C',(29,6),(25,7),(27,6)),('C',(33,11),(32,6),(33,8)),('C',(32,18),(35,13),(35,15)),('C',(42,21),(36,15),(42,15)),('C',(39,26),(42,23),(41,25)),('C',(42,30),(40,27),(42,28)),('C',(38,36),(42,33),(42,36)),('C',(24,30),(36,38),(31,35))],True)
        path('stem',(24,30),[('L',(24,37)),('C',(29,42),(24,40),(26,42))]);join('stem','clover')
