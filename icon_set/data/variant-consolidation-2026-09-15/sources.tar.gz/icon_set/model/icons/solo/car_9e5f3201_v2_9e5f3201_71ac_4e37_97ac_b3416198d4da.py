"""car-9e5f3201: next hundred AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '9e5f3201-71ac-4e37-97ac-b3416198d4da'
SOURCE_PATH = 'icons-json/transportation/car_9e5f3201-71ac-4e37-97ac-b3416198d4da.json'
AUTHOR = 'gpt-6'

class Car9e5f3201Variant2(Solo48):
    icon_id = 'car-9e5f3201-v2'
    variant_of = 'car-9e5f3201'
    variant_label = 'AI review · next 100'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'transportation'
    aliases = ()
    keywords = ('car', 'transportation', 'solo-ai-next100')

    def build(self):
        # Plan: Keep this compact car roof type and stance. Four exact tyre quadrants meet a smoothly rounded lower body at shared nodes; the wheels retain clear round interiors. Small tangent curves soften the shoulders while retaining the original roof shape.
        # Reference: Lucide car original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('body',(4,28),[('L', (4, 25)), ('C', (5, 24), (4.0, 24.333333333333332), (4.333333333333333, 24.0)), ('L', (9, 22)), ('C', (10, 21), (9.666666666666666, 22.0), (10.0, 21.666666666666668)), ('L', (16, 9)), ('C', (17, 8), (16.0, 8.333333333333334), (16.333333333333332, 8.0)), ('L', (27, 8)), ('C', (29, 9), (27.666666666666668, 8.0), (28.333333333333332, 8.333333333333334)), ('L', (35, 21)), ('C', (37, 22), (35.666666666666664, 21.666666666666668), (36.333333333333336, 22.0)), ('L', (40, 22)), ('L', (43, 24)), ('C', (44, 25), (43.666666666666664, 24.0), (44.0, 24.333333333333332))]+[('L',(44,28)),('A',(40,32),4,4,True),('L',(36,32)),('L',(12,32)),('L',(8,32)),('A',(4,28),4,4,True)],True)

        for x in (12,36):
         path(f'wheel-{x}',(x,32),[('A',(x+4,36),4,4,True),('A',(x,40),4,4,True),('A',(x-4,36),4,4,True),('A',(x,32),4,4,True)],True)
         join(f'wheel-{x}','body')
        line('belt',(11,20),(35,20));join('belt','body')
