"""arrow-circle-left-4: Smooth open ring arrow; earlier revisions preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '71c91594-3568-5185-a426-59b87ba667ee'
SOURCE_PATH = 'icons-json/arrows/arrow circle left 4_71c91594-3568-5185-a426-59b87ba667ee.json'
AUTHOR = 'gpt-6'

class ArrowCircleLeft4Variant2(Solo48):
    icon_id = 'arrow-circle-left-4-v2'
    variant_of = 'arrow-circle-left-4'
    variant_label = 'Smooth open ring arrow'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'arrows'
    aliases = ()
    keywords = ('solo-ai-full-set', 'arrow-circle-left-4')

    def build(self):
        # Plan: Preserve the arrow attached to an open ring; reconstruct the ring as coherent cardinal arcs.
        # Reference: Original subject; preserve the distinctive silhouette and proportions.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L" and tuple(end) == tuple(here):
                    continue
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        def pt(x,y):return (48-y,x) if 'left'=='left' else (x,y)
        path('ring-shaft',pt(24,34),[('L',pt(24,6)),('A',pt(6,24),18,18,False),('A',pt(24,42),18,18,False),('A',pt(42,24),18,18,False),('C',pt(29,7),pt(42,16),pt(37,9))])
        path('head',pt(15,25),[('L',pt(24,34)),('L',pt(33,25))]);join('head','ring-shaft')
