"""bread: next fifty AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '8ddeed7d-559d-4b14-9b46-092f255cb54a'
SOURCE_PATH = 'icons-json/symbol/bread_8ddeed7d-559d-4b14-9b46-092f255cb54a.json'
AUTHOR = 'gpt-6'

class BreadVariant2(Solo48):
    icon_id = 'bread-v2'
    variant_of = 'bread'
    variant_label = 'AI review · next 50'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'symbol'
    aliases = ()
    keywords = ('bread', 'symbol', 'solo-ai-next50')

    def build(self):
        # Plan: A square sandwich-loaf slice has a wide softly domed crown and straight lower sides. Both sides derive from one axis; no tiny crust texture.
        # Reference: Lucide sandwich original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('bread',(12,42),[('L',(12,22)),('C',(6,14),(8,22),(6,19)),('C',(16,6),(6,8),(10,6)),('L',(32,6)),('C',(42,14),(38,6),(42,8)),('C',(36,22),(42,19),(40,22)),('L',(36,42)),('L',(12,42))],True)
