"""casino-clover: next hundred AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '940923da-19e4-4b49-811d-53f2118f022d'
SOURCE_PATH = 'icons-json/entertainment/casino clover_940923da-19e4-4b49-811d-53f2118f022d.json'
AUTHOR = 'gpt-6'

class CasinoCloverVariant2(Solo48):
    icon_id = 'casino-clover-v2'
    variant_of = 'casino-clover'
    variant_label = 'AI review · next 100'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'entertainment'
    aliases = ()
    keywords = ('casino', 'clover', 'entertainment', 'solo-ai-next100')

    def build(self):
        # Plan: Keep a three-lobed clover with rounded leaf ends and a narrow central stem. Both side leaves mirror around the shared stem.
        # Reference: Lucide clover original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('clover',(24,33),[('C',(8,28),(12,40),(8,34)),('C',(17,18),(8,21),(12,17)),('C',(16,11),(14,15),(14,12)),('C',(24,4),(16,6),(20,4)),('C',(32,11),(28,4),(32,6)),('C',(31,18),(34,12),(34,15)),('C',(40,28),(36,17),(40,21)),('C',(24,33),(40,34),(36,40))],True)
        line('stem',(24,33),(24,44));join('stem','clover')
