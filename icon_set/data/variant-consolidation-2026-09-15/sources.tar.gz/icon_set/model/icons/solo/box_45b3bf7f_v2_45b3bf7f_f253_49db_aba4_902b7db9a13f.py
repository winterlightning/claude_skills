"""box-45b3bf7f: next fifty AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '45b3bf7f-f253-49db-aba4-902b7db9a13f'
SOURCE_PATH = 'icons-json/shipping/box_45b3bf7f-f253-49db-aba4-902b7db9a13f.json'
AUTHOR = 'gpt-6'

class Box45b3bf7fVariant2(Solo48):
    icon_id = 'box-45b3bf7f-v2'
    variant_of = 'box-45b3bf7f'
    variant_label = 'AI review · next 50'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'shipping'
    aliases = ()
    keywords = ('box', 'shipping', 'solo-ai-next50')

    def build(self):
        # Plan: A three-quarter cube uses one top diamond and two equal visible sides. Every meeting edge shares an integer node; perspective is intentional.
        # Reference: Lucide box original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        poly('carton',(6,16),(15,11),(24,6),(42,16),(42,32),(24,42),(6,32),closed=True)
        poly('rim',(6,16),(24,26),(33,21),(42,16));line('corner',(24,26),(24,42));join('rim','carton');join('corner','rim');join('corner','carton')
