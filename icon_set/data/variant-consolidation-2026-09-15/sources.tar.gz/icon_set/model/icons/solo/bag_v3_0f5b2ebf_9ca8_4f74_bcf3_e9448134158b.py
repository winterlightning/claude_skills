"""bag: Soft everyday tote; earlier revisions preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '0f5b2ebf-9ca8-4f74-bcf3-e9448134158b'
SOURCE_PATH = 'icons-json/photography/bag_0f5b2ebf-9ca8-4f74-bcf3-e9448134158b.json'
AUTHOR = 'gpt-6'

class BagVariant3(Solo48):
    icon_id = 'bag-v3'
    variant_of = 'bag-v2'
    variant_label = 'Soft everyday tote'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'photography'
    aliases = ()
    keywords = ('solo-ai-refine', 'solo-ai-first50', 'bag')

    def build(self):
        # Plan: A wide softly rounded tote with a broad arch handle. The square silhouette and generous lower radii distinguish it from the tall carriers.
        # Reference: Lucide handbag: original and atomic-debug geometry.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        path('handle',(16,18),[('L',(16,14)),('A',(32,14),8,8,True),('L',(32,18))])
        path('body',(10,18),[('L',(16,18)),('L',(32,18)),('L',(38,18)),('C',(42,30),(40,22),(42,26)),('C',(30,42),(42,39),(38,42)),('L',(18,42)),('C',(6,30),(10,42),(6,39)),('C',(10,18),(6,26),(8,22))],True)
        join('handle','body')
