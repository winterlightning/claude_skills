"""book-close-49781b64: next fifty AI review; original preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '49781b64-ccc2-5e53-93f8-360efdda93fc'
SOURCE_PATH = 'icons-json/content/book close_49781b64-ccc2-5e53-93f8-360efdda93fc.json'
AUTHOR = 'gpt-6'

class BookClose49781b64Variant2(Solo48):
    icon_id = 'book-close-49781b64-v2'
    variant_of = 'book-close-49781b64'
    variant_label = 'AI review · next 50'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'content'
    aliases = ()
    keywords = ('book', 'close', 'content', 'solo-ai-next50')

    def build(self):
        # Plan: A square-cornered hardback has a centered built-in ribbon and a narrow lower page block. The ribbon is physical book furniture and shares the top edge.
        # Reference: Lucide book-marked original and atomic-debug construction.

        # Typed path helpers preserve each continuous stroke and its round joins.
        def path(name, start, commands, closed=False):
            members = []
            here = start
            for index, command in enumerate(commands):
                ident = f"{name}-{index}"
                kind, end, *args = command
                if kind == "L":
                    self.add_line(ident, here, end)
                elif kind == "A":
                    rx, ry, sweep = args
                    self.add_arc(ident, here, end, radius_x=rx, radius_y=ry, sweep=sweep)
                elif kind == "C":
                    c1, c2 = args
                    self.add_bezier(ident, here, (c1, c2, end))
                members.append(ident)
                here = end
            self.add_contour(name, *members, closed=closed)
        def circle(name, cx, cy, r):
            path(name, (cx-r,cy), [("A",(cx+r,cy),r,r,True), ("A",(cx-r,cy),r,r,True)], True)
        def rounded(name, x0, y0, x1, y1, r):
            path(name, (x0+r,y0), [
                ("L",(x1-r,y0)), ("A",(x1,y0+r),r,r,True),
                ("L",(x1,y1-r)), ("A",(x1-r,y1),r,r,True),
                ("L",(x0+r,y1)), ("A",(x0,y1-r),r,r,True),
                ("L",(x0,y0+r)), ("A",(x0+r,y0),r,r,True)], True)
        line = self.add_line
        poly = self.add_polyline
        join = lambda a,b: self.relate("connect",a,b)
        poly('cover',(8,4),(20,4),(32,4),(40,4),(40,36),(40,44),(8,44),(8,36),closed=True)
        line('pages',(8,36),(40,36));join('pages','cover')
        poly('ribbon',(20,4),(20,20),(26,16),(32,20),(32,4));join('ribbon','cover')
