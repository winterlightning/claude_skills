"""Google podcast logo 2 (logos), converted from the icons-json construction graph by json_to_solo --mode fit. VRECT_L keyshape; curves fitted to integer lines and arcs."""
from ...keyshapes import Keyshape
from ._base import Solo48

SOURCE_ICON_ID = 'faa1ee65-30bb-4281-aa2f-de340011fbbc'
SOURCE_PATH = 'pictographic-primitives/logos/google podcast logo 2_faa1ee65-30bb-4281-aa2f-de340011fbbc.svg'
AUTHOR = 'gpt-6'
ORIGINAL_AUTHOR = 'json_to_solo'
REVIEWED_BY = 'gpt-6'
REVIEW_ACTION = 'geometry-retained-after-visual-review'

class GooglePodcastLogo2(Solo48):
    icon_id = 'google-podcast-logo-2'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'logos'
    aliases = ()
    keywords = ('google', 'podcast', 'logo', 'logos')

    def build(self):
        self.add_line('e0', (24, 4), (24, 44))
        self.add_line('e1', (16, 11), (16, 37))
        self.add_line('e2', (32, 11), (32, 37))
        self.add_line('e3', (40, 21), (40, 27))
        self.add_line('e4', (8, 27), (8, 22))
        self.add_contour('c0', 'e0')
        self.add_contour('c1', 'e1')
        self.add_contour('c2', 'e2')
        self.add_contour('c3', 'e3')
        self.add_contour('c4', 'e4')
