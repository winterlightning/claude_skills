"""Barcode (shopping), converted from the icons-json construction graph by json_to_solo --mode fit. HRECT_L keyshape; curves fitted to integer lines and arcs."""
from ...keyshapes import Keyshape
from ._base import Solo48

SOURCE_ICON_ID = 'bf664f43-31f6-4459-9d12-7a1d85a97306'
SOURCE_PATH = 'pictographic-primitives/shopping/barcode_bf664f43-31f6-4459-9d12-7a1d85a97306.svg'
AUTHOR = 'gpt-6'
ORIGINAL_AUTHOR = 'json_to_solo'
REVIEWED_BY = 'gpt-6'
REVIEW_ACTION = 'geometry-retained-after-visual-review'

class BarcodeBf664f43(Solo48):
    icon_id = 'barcode-bf664f43'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'shopping'
    aliases = ()
    keywords = ('barcode', 'shopping')

    def build(self):
        self.add_line('e0', (4, 40), (4, 8))
        self.add_line('e1', (31, 40), (31, 8))
        self.add_line('e2', (18, 40), (18, 8))
        self.add_line('e3', (44, 40), (44, 9))
        self.add_contour('c0', 'e0')
        self.add_contour('c1', 'e1')
        self.add_contour('c2', 'e2')
        self.add_contour('c3', 'e3')
