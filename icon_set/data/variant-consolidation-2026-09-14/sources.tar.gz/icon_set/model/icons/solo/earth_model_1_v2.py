"""Earth model 1 (maps), converted from the icons-json construction graph by json_to_solo --mode fit. VRECT_L keyshape; curves fitted to integer lines and arcs."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = 'a5e62027-4155-4c3f-9eea-0fcf4e0f687b'
SOURCE_PATH = 'icons-json/maps/earth model 1_a5e62027-4155-4c3f-9eea-0fcf4e0f687b.json'
AUTHOR = 'gpt-6'

class EarthModel1Variant2(Solo48):
    icon_id = 'earth-model-1-v2'
    variant_of = 'earth-model-1'
    variant_label = 'Open counters and smoother curves'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'maps'
    aliases = ()
    keywords = ('earth', 'model', 'maps')

    def _circle(self, name, x, y, r, ry=None):
        ry = r if ry is None else ry
        self.add_arc(name + '-a', (x - r, y), (x + r, y), radius_x=r, radius_y=ry)
        self.add_arc(name + '-b', (x + r, y), (x - r, y), radius_x=r, radius_y=ry)
        self.add_contour(name, name + '-a', name + '-b', closed=True)

    def _path(self, name, start, parts, closed=False):
        ids = []
        p = start
        for j, s in enumerate(parts):
            i = f'{name}-{j}'
            q = s[1]
            if s[0] == 'L':
                self.add_line(i, p, q)
            else:
                self.add_arc(i, p, q, radius_x=s[2], radius_y=s[3], sweep=s[4])
            ids.append(i)
            p = q
        self.add_contour(name, *ids, closed=closed)

    def build(self):
        self._circle('globe', 18, 16, 10)
        self._path('meridian', (32, 4), [('A', (40, 20), 20, 20, True), ('A', (22, 34), 18, 14, True), ('A', (8, 32), 24, 24, True)])
        self.add_line('stem', (22, 34), (22, 36))
        self.relate('connect', 'stem', 'meridian')
        self._path('base', (13, 44), [('A', (22, 36), 9, 8, True), ('A', (31, 44), 9, 8, True), ('L', (13, 44))], True)
        self.relate('connect', 'stem', 'base')
