"""A woman’s bobbed head wearing a flight attendant’s pillbox hat.

Centre fringe and closed hair tips omitted to retain a clear pillbox silhouette.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-woman-air-hostess-1.svg'
AUTHOR = 'gpt-6'

class AvatarWomanAirHostess1(Solo48):
    icon_id = 'avatar-woman-air-hostess-1'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'woman', 'air', 'hostess', '1', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # HRECT_L: author to exact SOLO48 centerline envelope.
        self.add_polyline('hat',(12,20),(16,8),(32,8),(36,20),(12,20))
        self.add_arc('face',(36,24),(12,24),radius_x=12,radius_y=16)
        self.add_line('temple-left',(12,20),(12,24))
        self.add_line('temple-right',(36,24),(36,20))
        self.add_contour('jaw','temple-left')
        self.relate('connect','hat','temple-left')
        self.relate('connect','hat','temple-right')
        self.relate('connect','face','temple-left')
        self.relate('connect','face','temple-right')
        for side,sign in [('left',-1),('right',1)]:
            self.add_bezier('hair-'+side,(24+sign*12,20),((24+sign*20,24),(24+sign*20,32),(24+sign*20,40)))
            self.relate('connect','hair-'+side,'hat')
            self.relate('connect','hair-'+side,'temple-'+side)
