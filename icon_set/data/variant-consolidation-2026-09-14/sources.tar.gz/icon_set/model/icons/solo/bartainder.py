"""A bartender’s head wearing a flat service cap.

Kept the shallow cap and blank face; corrected concept spelling in descriptive text.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/bartainder.svg'
AUTHOR = 'gpt-6'

class Bartainder(Solo48):
    icon_id = 'bartainder'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('bartainder', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # VRECT_L: author to exact SOLO48 centerline envelope.
        self.add_arc('crown-left',(8,8),(24,4),radius_x=16,radius_y=4)
        self.add_arc('crown-right',(24,4),(40,8),radius_x=16,radius_y=4)
        self.add_line('right',(40,8),(36,16))
        self.add_line('brim',(36,16),(12,16))
        self.add_line('left',(12,16),(8,8))
        self.add_contour('hat','crown-left','crown-right','right','brim','left',closed=True)
        self.add_bezier('face',(36,16),((40,28),(40,44),(24,44)),((8,44),(8,28),(12,16)))
        self.relate('connect','hat','face')
