# Variant of folding-hand-fan; parent file remains unchanged.
'Two inner fan ribs. Independent feedback revision; preserve source subject.'
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = 'e42cbce0-9cff-57ad-9095-13c8d5b279a0'
SOURCE_PATH = 'pictographic-primitives/culture/batch-03/fan_e42cbce0-9cff-57ad-9095-13c8d5b279a0.svg'
AUTHOR = 'gpt-6'

class FoldingHandFanVariant2(Solo48):
    icon_id = 'folding-hand-fan-v2'
    variant_of = 'folding-hand-fan'
    variant_label = 'Two inner fan ribs'
    keyshape = Keyshape.HRECT_XL
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'culture/objects'
    aliases = ()
    keywords = ('fan', 'folding fan', 'hand fan', 'japanese', 'asian', 'accessory', 'cooling', 'traditional')

    def build(self) -> None:
        self.add_arc('edge-left-outer', (6, 18), (12, 8), radius_x=29)
        self.add_arc('edge-left-inner', (12, 8), (24, 6), radius_x=29)
        self.add_arc('edge-right-inner', (24, 6), (36, 8), radius_x=29)
        self.add_arc('edge-right-outer', (36, 8), (42, 18), radius_x=29)
        self.add_line('right-rib', (42, 18), (24, 42))
        self.add_line('left-rib', (24, 42), (6, 18))
        self.add_contour('fan', 'edge-left-outer', 'edge-left-inner', 'edge-right-inner', 'edge-right-outer', 'right-rib', 'left-rib', closed=True)
        self.add_line('rib-left', (12, 8), (24, 42))
        self.add_line('rib-right', (36, 8), (24, 42))
        self.relate('connect', 'fan', 'rib-left')
        self.relate('connect', 'fan', 'rib-right')

        self.relate('connect','rib-left','rib-right')
