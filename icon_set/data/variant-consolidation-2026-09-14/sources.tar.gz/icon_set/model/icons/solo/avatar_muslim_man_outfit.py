"""A man’s head in a cap with two falling headcloth ends.

Kept cap, broad band and two cloth ends; no facial detail added.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-muslim-man-outfit.svg'
AUTHOR = 'gpt-6'

class AvatarMuslimManOutfit(Solo48):
    icon_id = 'avatar-muslim-man-outfit'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'muslim', 'man', 'outfit', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # HRECT_L: author to exact SOLO48 centerline envelope.
        axis, brim_y = 24, 20
        self.add_arc('cap',(12,brim_y),(36,brim_y),radius_x=12,radius_y=12)
        self.add_arc('face',(36,brim_y),(12,brim_y),radius_x=12,radius_y=20)
        self.add_contour('head','cap','face',closed=True)
        self.add_polyline('brim',(4,brim_y),(12,brim_y),(36,brim_y),(44,brim_y))
        self.relate('connect','head','brim')
        for side,sign in [('left',-1),('right',1)]:
            self.add_line('drape-'+side,(axis+sign*12,brim_y),(axis+sign*20,40))
            self.relate('connect','head','drape-'+side)
            self.relate('connect','brim','drape-'+side)
