"""A woman’s head with a broad firefighter helmet and side hair.

Round helmet badge reduced to a raised central helmet ridge to avoid a crowded ring.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-fire-fighter-woman.svg'
AUTHOR = 'gpt-6'

class AvatarFireFighterWoman(Solo48):
    icon_id = 'avatar-fire-fighter-woman'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'fire', 'fighter', 'woman', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # SQUARE: author to exact SOLO48 centerline envelope.
        axis = 24
        self.add_arc('helmet',(6,24),(24,6),radius_x=18)
        self.add_arc('helmet-right',(24,6),(42,24),radius_x=18)
        self.add_contour('crown','helmet','helmet-right')
        self.add_polyline('brim',(6,24),(12,24),(36,24),(42,24))
        self.relate('connect','crown','brim')
        self.add_line('crest',(24,6),(24,16))
        self.relate('connect','crown','crest')
        self.add_arc('face',(36,24),(12,24),radius_x=12,radius_y=18)
        self.relate('connect','face','brim')
        for side,sign in [('left',-1),('right',1)]:
            self.add_bezier('hair-'+side,(axis+sign*12,24),((axis+sign*12,34),(axis+sign*15,39),(axis+sign*18,42)))
            self.relate('connect','hair-'+side,'face')
            self.relate('connect','hair-'+side,'brim')
