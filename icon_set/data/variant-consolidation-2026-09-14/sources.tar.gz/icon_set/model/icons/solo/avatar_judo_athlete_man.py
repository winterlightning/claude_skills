"""A round male head with a swept, peaked fringe.

Facial detail absent in source; kept a single asymmetric swept fringe.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-judo-athlete-man.svg'
AUTHOR = 'gpt-6'

class AvatarJudoAthleteMan(Solo48):
    icon_id = 'avatar-judo-athlete-man'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'judo', 'athlete', 'man', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # SQUARE: author to exact SOLO48 centerline envelope.
        axis, radius = 24, 18
        self.add_arc('crown',(axis-radius,24),(axis+radius,24),radius_x=radius)
        self.add_arc('jaw',(axis+radius,24),(axis-radius,24),radius_x=radius)
        self.add_contour('head','crown','jaw',closed=True)
        self.add_bezier('fringe',(6,24), ((14,26),(21,21),(28,14)), ((31,20),(35,24),(42,24)))
        self.relate('connect','head','fringe')
