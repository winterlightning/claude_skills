"""A woman’s head in a peaked police cap with side hair.

Tiny cap badge and secondary curved visor omitted; peaked crown and band preserved.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-police-woman-1.svg'
AUTHOR = 'gpt-6'

class AvatarPoliceWoman1(Solo48):
    icon_id = 'avatar-police-woman-1'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'police', 'woman', '1', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # SQUARE: author to exact SOLO48 centerline envelope.
        self.add_polyline('cap',(6,16),(24,6),(42,16),(38,24),(10,24),(6,16))
        self.add_line('band',(6,16),(42,16))
        self.relate('connect','cap','band')
        self.add_arc('face',(38,24),(10,24),radius_x=14,radius_y=18)
        self.relate('connect','cap','face')
        for side,sign in [('left',-1),('right',1)]:
            self.add_bezier('hair-'+side,(24+sign*14,24),((24+sign*14,32),(24+sign*15,38),(24+sign*18,42)))
            self.relate('connect','hair-'+side,'cap')
            self.relate('connect','hair-'+side,'face')
