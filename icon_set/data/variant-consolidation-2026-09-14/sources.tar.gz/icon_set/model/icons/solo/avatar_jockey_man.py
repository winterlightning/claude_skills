"""A jockey’s round head wearing a domed riding helmet.

Two narrow helmet panels reduced to one central seam.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-jockey-man.svg'
AUTHOR = 'gpt-6'

class AvatarJockeyMan(Solo48):
    icon_id = 'avatar-jockey-man'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'jockey', 'man', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # SQUARE: author to exact SOLO48 centerline envelope.
        axis, radius, brim = 24, 18, 24
        self.add_arc('helmet-left',(axis-radius,brim),(axis,6),radius_x=radius)
        self.add_arc('helmet-right',(axis,6),(axis+radius,brim),radius_x=radius)
        self.add_arc('face',(axis+radius,brim),(axis-radius,brim),radius_x=radius)
        self.add_contour('outline','helmet-left','helmet-right','face',closed=True)
        self.add_line('brim',(6,24),(42,24))
        self.relate('connect','outline','brim')
        self.add_line('seam',(24,6),(24,16))
        # The seam meets the actual top apex of the helmet.
        self.relate('connect','outline','seam')
