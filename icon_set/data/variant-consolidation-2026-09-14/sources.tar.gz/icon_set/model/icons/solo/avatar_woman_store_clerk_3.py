"""A woman’s round head with a swept fringe and a side ponytail.

Ponytail reduced to one open curved strand; deliberate right-sided asymmetry retained.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-woman-store-clerk-3.svg'
AUTHOR = 'gpt-6'

class AvatarWomanStoreClerk3(Solo48):
    icon_id = 'avatar-woman-store-clerk-3'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'woman', 'store', 'clerk', '3', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # HRECT_L: author to exact SOLO48 centerline envelope.
        axis, radius = 20, 16
        self.add_arc('crown',(4,24),(36,24),radius_x=radius)
        self.add_arc('jaw',(36,24),(4,24),radius_x=radius)
        self.add_contour('head','crown','jaw',closed=True)
        self.add_bezier('fringe',(4,24),((14,24),(20,20),(24,16)),((26,20),(30,24),(36,24)))
        self.relate('connect','head','fringe')
        self.add_bezier('ponytail',(36,24),((44,24),(36,32),(44,40)))
        self.relate('connect','head','ponytail')
        self.relate('connect','fringe','ponytail')
