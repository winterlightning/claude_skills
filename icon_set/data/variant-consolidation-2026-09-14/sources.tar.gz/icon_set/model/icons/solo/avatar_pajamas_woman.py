"""A woman’s head with hair wrapped in a twisted towel.

Small upper towel fold omitted; kept diagonal twist and wrap silhouette.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-pajamas-woman.svg'
AUTHOR = 'gpt-6'

class AvatarPajamasWoman(Solo48):
    icon_id = 'avatar-pajamas-woman'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'pajamas', 'woman', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # VRECT_L: author to exact SOLO48 centerline envelope.
        self.add_arc('wrap-top',(8,24),(24,4),radius_x=16,radius_y=20)
        self.add_arc('wrap-right',(24,4),(40,24),radius_x=16,radius_y=20)
        self.add_arc('jaw',(40,24),(8,24),radius_x=16,radius_y=20)
        self.add_contour('head','wrap-top','wrap-right','jaw',closed=True)
        twist_node=(20,20)
        self.add_bezier('twist',(24,4),((32,6),(32,12),twist_node),((16,23),(12,24),(8,24)))
        self.relate('connect','head','twist')
        self.add_bezier('fold',twist_node,((28,20),(36,20),(40,24)))
        self.relate('connect','head','fold')
        self.relate('connect','twist','fold')
