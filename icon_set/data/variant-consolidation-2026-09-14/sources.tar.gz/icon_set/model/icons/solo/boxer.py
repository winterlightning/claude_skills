"""A boxer’s head protected by padded headgear with two eye openings.

Kept padded circular headgear and paired openings; no facial marks added.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/boxer.svg'
AUTHOR = 'gpt-6'

class Boxer(Solo48):
    icon_id = 'boxer'
    keyshape = Keyshape.CIRCLE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('boxer', 'head', 'portrait')

    def build(self):
        # Circular headgear radius 20; quarter-like sections expose each true join.
        pts = [(8,12),(24,4),(40,12),(44,24),(40,36),(24,44),(8,36),(4,24),(8,12)]
        members=[]
        for i,(a,b) in enumerate(zip(pts,pts[1:])):
            name=f'outline-{i}'
            self.add_arc(name,a,b,radius_x=20)
            members.append(name)
        self.add_contour('headgear',*members,closed=True)
        for side,sign in [('left',-1),('right',1)]:
            self.add_bezier('eye-top-'+side,(24+sign*16,12),((24+sign*12,22),(24+sign*2,20),(24,32)))
            self.add_bezier('eye-base-'+side,(24,32),((24+sign*6,32),(24+sign*12,34),(24+sign*16,36)))
            self.relate('connect','headgear','eye-top-'+side)
            self.relate('connect','headgear','eye-base-'+side)
        for a,b in [('eye-top-left','eye-top-right'),('eye-base-left','eye-base-right'),('eye-top-left','eye-base-left'),('eye-top-right','eye-base-right'),('eye-top-left','eye-base-right'),('eye-top-right','eye-base-left')]:
            self.relate('connect',a,b)
