"""A round head wearing a sailor cap with a wide band.

Small brim taper retained with one clear 8-unit band.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-ship-crew-navy-1.svg'
AUTHOR = 'gpt-6'

class AvatarShipCrewNavy1(Solo48):
    icon_id = 'avatar-ship-crew-navy-1'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'ship', 'crew', 'navy', '1', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # VRECT_L: author to exact SOLO48 centerline envelope.
        self.add_arc('crown',(12,16),(36,16),radius_x=12)
        self.add_polyline('band',(12,16),(8,16),(12,24),(36,24),(40,16),(36,16),(12,16))
        self.relate('connect','crown','band')
        self.add_arc('face',(36,24),(12,24),radius_x=12,radius_y=20)
        self.relate('connect','face','band')
