"""Raised the muzzle while retaining horns and ears; split the crown at its horn attachment.

Keyshape SQUARE: visible bounds (4, 4, 44, 44).
Reference: No useful exact match.
"""
# Independent repair of cow-head-with-horns; parent preserved.
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '97580ac4-7b89-40b3-93f5-d7ec65e96fa7'
SOURCE_PATH = 'pictographic-primitives/animals/cow_97580ac4-7b89-40b3-93f5-d7ec65e96fa7.svg'
AUTHOR = 'gpt-6'

class CowHeadWithHornsVariant2(Solo48):
    icon_id = 'cow-head-with-horns-v2'
    variant_of = 'cow-head-with-horns'
    variant_label = 'Fit current SOLO48 bounds and spacing'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'animals'
    aliases = ()
    keywords = ('cow', 'cattle', 'head', 'horns', 'muzzle', 'farm', 'bovine', 'dairy')

    # Symbol plan: retain the subject and shared attachment stations;
    # fit the current keyshape by adjusting the owning cap, base or repeat.
    def build(self) -> None:
        self.add_arc('crown-left', (14, 16), (24, 8), radius_x=10, radius_y=8)
        self.add_arc('crown-right', (24, 8), (34, 16), radius_x=10, radius_y=8)
        self.add_contour('crown', 'crown-left', 'crown-right')
        self.add_line('cheek-left', (14, 16), (16, 33))
        self.add_line('cheek-right', (34, 16), (32, 33))
        self.add_arc('muzzle-bottom', (32, 33), (16, 33), radius_x=8, radius_y=9, sweep=True)
        self.add_contour('head', 'cheek-left', closed=False)
        self.add_contour('right', 'cheek-right', 'muzzle-bottom', closed=False)
        self.relate('connect', 'crown', 'head')
        self.relate('connect', 'crown', 'right')
        self.relate('connect', 'head', 'right')
        self.add_arc('muzzle-top', (16, 33), (32, 33), radius_x=8, radius_y=5, sweep=True)
        self.relate('connect', 'muzzle-top', 'head')
        self.relate('connect', 'muzzle-top', 'right')
        self.add_arc('horn-left', (24, 8), (6, 6), radius_x=19, radius_y=6, sweep=True)
        self.relate('connect', 'horn-left', 'crown')
        self.add_arc('ear-left', (14, 16), (6, 26), radius_x=12, radius_y=10, sweep=True)
        self.relate('connect', 'ear-left', 'crown')
        self.relate('connect', 'ear-left', 'head')
        self.add_arc('horn-right', (24, 8), (42, 6), radius_x=19, radius_y=6, sweep=False)
        self.relate('connect', 'horn-right', 'crown')
        self.add_arc('ear-right', (34, 16), (42, 26), radius_x=12, radius_y=10, sweep=False)
        self.relate('connect', 'ear-right', 'crown')
        self.relate('connect', 'ear-right', 'right')
