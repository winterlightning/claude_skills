# Review candidate; original preserved.
"""Curled silhouette, muzzle and two stripes in a broad tail. No useful local raccoon match; circular construction re-authored from the supplied image. Four stripes reduced to two."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = 'dcf6e72c-8224-5fad-bb7d-737e07df48dd'
SOURCE_PATH = 'pictographic-primitives/animals/raccoon_dcf6e72c-8224-5fad-bb7d-737e07df48dd.svg'
AUTHOR = 'gpt-6'

class CurledRaccoonVariant2(Solo48):
    icon_id = 'curled-raccoon-v2'
    variant_of = 'curled-raccoon'
    variant_label = 'Roomier openings — pending review'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'nature/animals'
    aliases = ()
    keywords = ('raccoon', 'curled', 'tail', 'stripes', 'mask', 'animal', 'wildlife', 'nocturnal')

    def build(self) -> None:
        """Opening repair: Opened the tiny ear triangle into a single inward ear mark; retained the curled tail and stripes."""
        self.add_line('outline-1', (6, 13), (9, 12))
        self.add_arc('outline-2', (9, 12), (24, 6), radius_x=20, radius_y=16, sweep=True)
        self.add_arc('outline-3', (24, 6), (42, 24), radius_x=22, radius_y=22, sweep=True)
        self.add_arc('outline-4', (42, 24), (24, 42), radius_x=22, radius_y=22, sweep=True)
        self.add_arc('outline-5', (24, 42), (12, 42), radius_x=20, radius_y=20, sweep=True)
        self.add_arc('outline-6', (12, 42), (6, 27), radius_x=20, radius_y=18, sweep=True)
        self.add_line('outline-7', (6, 27), (8, 27))
        self.add_line('outline-8', (8, 27), (16, 30))
        self.add_line('outline-9', (16, 30), (24, 36))
        self.add_arc('outline-10', (24, 36), (36, 24), radius_x=12, radius_y=12, sweep=False)
        self.add_contour('outline', 'outline-1', 'outline-2', 'outline-3', 'outline-4', 'outline-5', 'outline-6', 'outline-7', 'outline-8', 'outline-9', 'outline-10', closed=False)
        self.add_line('face-1', (6, 13), (6, 16))
        self.add_arc('face-2', (6, 16), (11, 21), radius_x=8, radius_y=5, sweep=False)
        self.add_line('face-3', (11, 21), (20, 21))
        self.add_arc('face-4', (20, 21), (26, 27), radius_x=6, radius_y=6, sweep=True)
        self.add_line('face-5', (26, 27), (26, 28))
        self.add_contour('face', 'face-1', 'face-2', 'face-3', 'face-4', 'face-5', closed=False)
        self.add_line('ear-1', (24, 6), (24, 10))
        self.add_line('stripe-one-1', (12, 42), (16, 30))
        self.add_contour('stripe-one', 'stripe-one-1', closed=False)
        self.add_line('stripe-two-1', (24, 42), (24, 36))
        self.add_contour('stripe-two', 'stripe-two-1', closed=False)
        self.add_dot('eye', (17, 12))
        self.relate('connect', 'outline', 'face')
        self.relate('connect', 'outline', 'stripe-one')
        self.relate('connect', 'outline', 'stripe-two')
