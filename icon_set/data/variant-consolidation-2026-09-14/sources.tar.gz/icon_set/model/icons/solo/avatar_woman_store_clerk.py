"""A woman’s head with centre-parted bob hair and outward tips.

Small closed hair-tip wedges opened; shared source hairstyle preserved. Head-only reference supplies no clothing or occupation mark.
References: supplied head-only render; human_ref/user.svg for round outlined
head vocabulary; Lucide user-round original and atomic geometry for clean arcs.
No body is present, so detached head/body clearance is not applicable.
"""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = None
SOURCE_PATH = 'work/head-solo/batch-01/references/avatar-woman-store-clerk.svg'
AUTHOR = 'gpt-6'

class AvatarWomanStoreClerk(Solo48):
    icon_id = 'avatar-woman-store-clerk'
    keyshape = Keyshape.HRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'people/heads'
    aliases = ()
    keywords = ('avatar', 'woman', 'store', 'clerk', 'head', 'portrait')

    def build(self):
        # Plan: one head, attached hair/headwear; dimensions and mirror axes shared.
        # HRECT_L: author to exact SOLO48 centerline envelope.
        axis = 24
        # Hair owns a mirrored outer silhouette and centre-part fringe; face is one ellipse half.
        for label, sign in [('left', -1), ('right', 1)]:
            p = lambda x,y: (axis + sign*x,y)
            self.add_arc('hair-'+label, (axis,8), p(20,24), radius_x=20, radius_y=16, sweep=sign>0)
            self.add_bezier('tip-'+label, p(20,24), (p(20,32),p(16,34),p(20,40)))
            self.add_contour('outer-'+label, 'hair-'+label, 'tip-'+label)
            self.add_arc('fringe-'+label, (axis,8), p(12,24), radius_x=12, radius_y=16, sweep=sign<0)
            self.relate('connect', 'outer-'+label, 'fringe-'+label)
        self.relate('connect','outer-left','outer-right')
        self.relate('connect','fringe-left','fringe-right')
        self.add_arc('face', (36,24), (12,24), radius_x=12, radius_y=16)
        for side in ['left','right']:
            self.relate('connect','face','fringe-'+side)
