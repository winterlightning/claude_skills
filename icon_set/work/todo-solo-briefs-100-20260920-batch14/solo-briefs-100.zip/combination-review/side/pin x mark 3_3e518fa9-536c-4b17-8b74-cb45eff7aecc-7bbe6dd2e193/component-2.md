# Diagonal Cancellation Cross

- source: `pictographic-primitives/_uncategorized_30/pin x mark 3_3e518fa9-536c-4b17-8b74-cb45eff7aecc.svg`
- source UUID: `3e518fa9-536c-4b17-8b74-cb45eff7aecc`
- family: sub
- render: `pin x mark 3_3e518fa9-536c-4b17-8b74-cb45eff7aecc.png`
- native 48px reference: `pin x mark 3_3e518fa9-536c-4b17-8b74-cb45eff7aecc@48.png`

Two straight diagonal strokes crossing at their centers. Exclude all surrounding subjects; this is a geometric cancellation mark, not a letter glyph.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
