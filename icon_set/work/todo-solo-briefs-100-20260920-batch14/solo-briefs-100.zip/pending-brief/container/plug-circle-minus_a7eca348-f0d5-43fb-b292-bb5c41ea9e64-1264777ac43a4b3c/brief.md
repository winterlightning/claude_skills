# Empty Circular Border

- Status: pending-brief
- Family: container
- Combination: container
- Component: 1 of 2
- Original source: pictographic-primitives/_uncategorized_31/plug circle minus_a7eca348-f0d5-43fb-b292-bb5c41ea9e64.svg
- Source copy: plug circle minus_a7eca348-f0d5-43fb-b292-bb5c41ea9e64.svg
- Source ID: a7eca348-f0d5-43fb-b292-bb5c41ea9e64
- Source SHA-256: 2ce66734fae40c890a248706afcc49358fb27bf2bf201441fee3f3bf678b89b8

## Component to generate

A plain circular enclosure with blank interior. Exclude the electrical plug and its cord.

## Exclude

Two-Prong Electrical Plug

## Why the reference was split

A distinct electrical plug is enclosed by a circular border.

## AI handoff

$icon-making
Process this pending component brief with the copied reference. Generate or reuse only Empty Circular Border as a standalone container icon. Do not recreate the combined reference.
The source is an unchanged copy of the full reference, not an extracted component. Visually isolate the named part. Preserve its reference identity and use the matching family skill.
You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and continue to exclude the other component.
Do not modify or move the original reference. Keep existing generated icons intact. Validate and build the new component; leave approval to the reviewer.
