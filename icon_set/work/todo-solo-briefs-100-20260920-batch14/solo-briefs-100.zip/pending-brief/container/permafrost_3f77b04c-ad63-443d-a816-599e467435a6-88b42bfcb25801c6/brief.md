# Empty Rounded Square

- Status: pending-brief
- Family: container
- Combination: container
- Component: 1 of 2
- Original source: pictographic-primitives/_uncategorized_30/permafrost_3f77b04c-ad63-443d-a816-599e467435a6.svg
- Source copy: permafrost_3f77b04c-ad63-443d-a816-599e467435a6.svg
- Source ID: 3f77b04c-ad63-443d-a816-599e467435a6
- Source SHA-256: bcc16c8c91dee8963d0421fd57590ba529e7e5bfe1f0984b0ead8b914f7799b3

## Component to generate

A rounded square border with a blank interior. Exclude every interior glyph or illustration.

## Exclude

Six-Spoke Snowflake

## Why the reference was split

A snowflake is separately enclosed by a rounded square.

## AI handoff

$icon-making
Process this pending component brief with the copied reference. Generate or reuse only Empty Rounded Square as a standalone container icon. Do not recreate the combined reference.
The source is an unchanged copy of the full reference, not an extracted component. Visually isolate the named part. Preserve its reference identity and use the matching family skill.
You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and continue to exclude the other component.
Do not modify or move the original reference. Keep existing generated icons intact. Validate and build the new component; leave approval to the reviewer.
