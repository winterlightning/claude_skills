# Woman Explorer with a Brimmed Hat

- source: `pictographic-primitives/_uncategorized_05/avatar adventure woman_2ee8f5f0-6cf6-43a9-8839-ed970895cf00.svg`
- render: `png/avatar adventure woman_2ee8f5f0-6cf6-43a9-8839-ed970895cf00.png` (look at this first)
- native 48px: `png/avatar adventure woman_2ee8f5f0-6cf6-43a9-8839-ed970895cf00@48.png`
- tags: woman, explorer, hat, backpack, hair, portrait, adventure
- family: solo — author with `$icon-solo`
- proposed icon_id: `woman-explorer-with-a-brimmed-hat`

- source UUID: `2ee8f5f0-6cf6-43a9-8839-ed970895cf00`

## Description

A front-facing explorer wears a tall banded hat above a plain face and outward-flaring hair. A rounded neckline and two backpack straps descend between broad shoulder outlines.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
