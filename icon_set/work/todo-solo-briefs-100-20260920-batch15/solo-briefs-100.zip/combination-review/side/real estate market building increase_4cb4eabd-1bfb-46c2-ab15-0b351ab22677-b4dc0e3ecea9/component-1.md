# Three Rising Bars with Rounded Tops

- source: `pictographic-primitives/_uncategorized_32/real estate market building increase_4cb4eabd-1bfb-46c2-ab15-0b351ab22677.svg`
- source UUID: `4cb4eabd-1bfb-46c2-ab15-0b351ab22677`
- family: solo
- render: `real estate market building increase_4cb4eabd-1bfb-46c2-ab15-0b351ab22677.png`
- native 48px reference: `real estate market building increase_4cb4eabd-1bfb-46c2-ab15-0b351ab22677@48.png`

Three vertical bars rise in height from left to right, with softly rounded upper corners. Exclude the arrow.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
