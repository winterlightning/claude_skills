# Four Playing Card Suits

- source: `pictographic-primitives/_uncategorized_10/card game symbols_6c01ed88-1571-4e62-904d-509e18f64c7d.svg`
- render: `png/card game symbols_6c01ed88-1571-4e62-904d-509e18f64c7d.png` (look at this first)
- native 48px: `png/card game symbols_6c01ed88-1571-4e62-904d-509e18f64c7d@48.png`
- tags: cards, suits, diamond, club, spade, heart, game
- family: solo — author with `$icon-solo`
- proposed icon_id: `four-playing-card-suits`

- source UUID: `6c01ed88-1571-4e62-904d-509e18f64c7d`

## Description

Four outlined card suits form a loose square: diamond at upper left, club at upper right, spade below left and heart below right. Each symbol remains separate.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
