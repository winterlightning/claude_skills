# Lower-Right Arrow

- Status: pending-brief
- Family: sub
- Combination: container
- Component: 2 of 2
- Original source: pictographic-primitives/_uncategorized_35/square arrow down left_0cb36b98-e0c5-4184-a2a5-b1149dd0db98.svg
- Source copy: square arrow down left_0cb36b98-e0c5-4184-a2a5-b1149dd0db98.svg
- Source ID: 0cb36b98-e0c5-4184-a2a5-b1149dd0db98
- Source SHA-256: b07e56e07ce767024e8397715303a057793f09b29a45db03551ce95cc40555ae

## Component to generate

A diagonal shaft descends to an open arrowhead at lower right. Exclude the square frame.

## Exclude

Rounded Square Frame

## Why the reference was split

The outer enclosure surrounds an independently recognizable mark rather than a physical structural part.

## AI handoff

$icon-making
Process this pending component brief with the copied reference. Generate or reuse only Lower-Right Arrow as a standalone sub icon. Do not recreate the combined reference.
The source is an unchanged copy of the full reference, not an extracted component. Visually isolate the named part. Preserve its reference identity and use the matching family skill.
You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and continue to exclude the other component.
Do not modify or move the original reference. Keep existing generated icons intact. Validate and build the new component; leave approval to the reviewer.
