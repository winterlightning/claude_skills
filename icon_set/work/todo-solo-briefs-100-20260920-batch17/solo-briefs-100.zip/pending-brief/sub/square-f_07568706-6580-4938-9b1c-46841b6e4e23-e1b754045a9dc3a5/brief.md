# Speech Bubble Outline

- Status: pending-brief
- Family: sub
- Combination: container
- Component: 2 of 2
- Original source: pictographic-primitives/_uncategorized_35/square f_07568706-6580-4938-9b1c-46841b6e4e23.svg
- Source copy: square f_07568706-6580-4938-9b1c-46841b6e4e23.svg
- Source ID: 07568706-6580-4938-9b1c-46841b6e4e23
- Source SHA-256: f413b7e51243a7e501025f47616dfac60baaf11f9f24d405cc4b716fae6917a6

## Component to generate

A rounded rectangular speech bubble has a short pointed tail descending near its lower left. Exclude the outer square.

## Exclude

Rounded Square Frame

## Why the reference was split

The outer enclosure surrounds an independently recognizable mark rather than a physical structural part.

## AI handoff

$icon-making
Process this pending component brief with the copied reference. Generate or reuse only Speech Bubble Outline as a standalone sub icon. Do not recreate the combined reference.
The source is an unchanged copy of the full reference, not an extracted component. Visually isolate the named part. Preserve its reference identity and use the matching family skill.
You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and continue to exclude the other component.
Do not modify or move the original reference. Keep existing generated icons intact. Validate and build the new component; leave approval to the reviewer.
