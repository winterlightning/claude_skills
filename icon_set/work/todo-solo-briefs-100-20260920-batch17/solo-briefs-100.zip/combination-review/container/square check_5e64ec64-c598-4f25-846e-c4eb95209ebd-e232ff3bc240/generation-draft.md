# Check in Rounded Square — reference review

- source: `pictographic-primitives/_uncategorized_35/square check_5e64ec64-c598-4f25-846e-c4eb95209ebd.svg`
- source UUID: `5e64ec64-c598-4f25-846e-c4eb95209ebd`
- classification: container_combination
- review: component_briefs_ready

The outer enclosure surrounds an independently recognizable mark rather than a physical structural part.

## Visual draft

Check in Rounded Square. A separate symbol sits inside a rounded square outline.

## 1. Rounded Square Frame (container)

A plain rounded square enclosure with an empty interior. Exclude all enclosed content, lettering, symbols and status marks.

## 2. Check Mark (sub)

An open check with a short descending left arm and a longer rising right arm. Exclude the surrounding frame and every other subject.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
