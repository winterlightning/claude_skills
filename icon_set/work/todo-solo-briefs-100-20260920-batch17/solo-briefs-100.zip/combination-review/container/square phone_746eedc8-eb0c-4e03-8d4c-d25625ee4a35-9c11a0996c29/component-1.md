# Rounded Square Frame

- source: `pictographic-primitives/_uncategorized_35/square phone_746eedc8-eb0c-4e03-8d4c-d25625ee4a35.svg`
- source UUID: `746eedc8-eb0c-4e03-8d4c-d25625ee4a35`
- family: container
- render: `square phone_746eedc8-eb0c-4e03-8d4c-d25625ee4a35.png`
- native 48px reference: `square phone_746eedc8-eb0c-4e03-8d4c-d25625ee4a35@48.png`

A plain rounded square enclosure with an empty interior. Exclude all enclosed content, lettering, symbols and status marks.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
