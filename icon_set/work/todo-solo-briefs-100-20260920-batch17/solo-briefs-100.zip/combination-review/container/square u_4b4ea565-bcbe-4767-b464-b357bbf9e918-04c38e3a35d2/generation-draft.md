# Right Arrow in Rounded Square — reference review

- source: `pictographic-primitives/_uncategorized_35/square u_4b4ea565-bcbe-4767-b464-b357bbf9e918.svg`
- source UUID: `4b4ea565-bcbe-4767-b464-b357bbf9e918`
- classification: container_combination
- review: component_briefs_ready

The outer enclosure surrounds an independently recognizable mark rather than a physical structural part.

## Visual draft

Right Arrow in Rounded Square. A separate symbol sits inside a rounded square outline.

## 1. Rounded Square Frame (container)

A plain rounded square enclosure with an empty interior. Exclude all enclosed content, lettering, symbols and status marks.

## 2. Rightward Arrow (sub)

A horizontal shaft ends in an open rightward arrowhead. Exclude the rounded square.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
