# Dashed Circular Enclosure

- source: `pictographic-primitives/_uncategorized_35/square dashed circle plus_b67f4e19-f005-4972-8fd5-b3a7a1f67e76.svg`
- source UUID: `b67f4e19-f005-4972-8fd5-b3a7a1f67e76`
- family: container
- render: `square dashed circle plus_b67f4e19-f005-4972-8fd5-b3a7a1f67e76.png`
- native 48px reference: `square dashed circle plus_b67f4e19-f005-4972-8fd5-b3a7a1f67e76@48.png`

A circular border consists of separated short dashes. Exclude the outer square and central plus.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
