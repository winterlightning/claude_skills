# Rounded Square Frame

- source: `pictographic-primitives/_uncategorized_35/square envelope_613bafeb-8e15-4a5f-b38b-6de37442d065.svg`
- source UUID: `613bafeb-8e15-4a5f-b38b-6de37442d065`
- family: container
- render: `square envelope_613bafeb-8e15-4a5f-b38b-6de37442d065.png`
- native 48px reference: `square envelope_613bafeb-8e15-4a5f-b38b-6de37442d065@48.png`

A plain rounded square enclosure with an empty interior. Exclude all enclosed content, lettering, symbols and status marks.

## Authoring handoff

You can try modifying a copy of the SVG reference to fit the icon design rules, or generate a new icon that matches the icon name. Either approach must follow the requested family's design rules and preserve the named subject's identity. Apply this only to the named component and exclude the other components. Keep the original reference unchanged.
