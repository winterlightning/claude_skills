# Tall Sombrero with Wide Curved Brim

- source: `pictographic-primitives/_uncategorized_35/sombrero_3e5c1ae0-8307-49ef-8b54-53bcabd5374c.svg`
- render: `png/sombrero_3e5c1ae0-8307-49ef-8b54-53bcabd5374c.png` (look at this first)
- native 48px: `png/sombrero_3e5c1ae0-8307-49ef-8b54-53bcabd5374c@48.png`
- tags: sombrero, hat, brim, crown, headwear, clothing
- family: solo — author with `$icon-solo`
- proposed icon_id: `tall-sombrero-with-wide-curved-brim`

- source UUID: `3e5c1ae0-8307-49ef-8b54-53bcabd5374c`

## Description

A sombrero has a tall tapering crown with a rounded top above a very broad brim. The brim's upper edge is straight, while its ends curve down into a shallow rounded base.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
