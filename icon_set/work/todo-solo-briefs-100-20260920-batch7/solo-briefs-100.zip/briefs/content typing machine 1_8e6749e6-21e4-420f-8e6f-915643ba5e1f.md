# Typewriter with Folded Corner Paper

- source: `pictographic-primitives/_uncategorized_12/content typing machine 1_8e6749e6-21e4-420f-8e6f-915643ba5e1f.svg`
- render: `png/content typing machine 1_8e6749e6-21e4-420f-8e6f-915643ba5e1f.png` (look at this first)
- native 48px: `png/content typing machine 1_8e6749e6-21e4-420f-8e6f-915643ba5e1f@48.png`
- tags: typewriter, paper, fold, carriage, writing, machine, vintage
- family: solo — author with `$icon-solo`
- proposed icon_id: `typewriter-with-folded-corner-paper`

- source UUID: `8e6749e6-21e4-420f-8e6f-915643ba5e1f`

## Description

A typewriter holds a tall sheet with one folded upper corner behind its carriage. A broad lower housing has a curved central recess, with short roller ends projecting sideways.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
