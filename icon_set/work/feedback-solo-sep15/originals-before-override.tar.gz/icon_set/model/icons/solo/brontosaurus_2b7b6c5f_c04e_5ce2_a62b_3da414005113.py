"""Replace the angular tail tip with a smooth rounded return. Independent feedback revision; parent preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '2b7b6c5f-c04e-5ce2-a62b-3da414005113'
SOURCE_PATH = 'pictographic-primitives/animals/dinosaur brontosaurus_2b7b6c5f-c04e-5ce2-a62b-3da414005113.svg'
AUTHOR = 'gpt-6'

class Brontosaurus(Solo48):
    icon_id = 'brontosaurus'
    keyshape = Keyshape.SQUARE
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'nature/animals'
    aliases = ()
    keywords = ('dinosaur', 'brontosaurus', 'sauropod', 'longneck', 'prehistoric', 'jurassic', 'reptile', 'extinct')

    def build(self) -> None:
        """Symbol plan: Replace the angular tail tip with a smooth rounded return. Reference: inspected current parent; no useful exact Lucide match selected."""
        self.add_arc('head', (8, 12), (8, 6), radius_x=2, radius_y=3)
        self.add_line('crown', (8, 6), (12, 6))
        self.add_arc('nape', (12, 6), (18, 12), radius_x=6)
        self.add_line('neck', (18, 12), (20, 26))
        self.add_arc('back', (20, 26), (36, 28), radius_x=16, radius_y=8)
        self.add_arc('tail-1', (36, 28), (42, 34), radius_x=6)
        self.add_arc('tail-2', (42, 34), (38, 38), radius_x=4)
        self.add_line('tail-3', (38, 38), (32, 36))
        self.add_line('tail-4', (32, 36), (32, 42))
        self.add_line('tail-5', (32, 42), (24, 42))
        self.add_line('tail-6', (24, 42), (24, 36))
        self.add_line('tail-7', (24, 36), (16, 34))
        self.add_line('tail-8', (16, 34), (16, 42))
        self.add_line('tail-9', (16, 42), (8, 42))
        self.add_line('tail-10', (8, 42), (8, 12))
        self.add_contour('dinosaur', 'head', 'crown', 'nape', 'neck', 'back', *['tail-' + str(i) for i in range(1, 11)], closed=True)
