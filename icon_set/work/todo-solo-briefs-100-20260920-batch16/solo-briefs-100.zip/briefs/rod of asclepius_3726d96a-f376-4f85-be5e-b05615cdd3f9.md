# Single Serpent Around a Staff

- source: `pictographic-primitives/_uncategorized_33/rod of asclepius_3726d96a-f376-4f85-be5e-b05615cdd3f9.svg`
- render: `png/rod of asclepius_3726d96a-f376-4f85-be5e-b05615cdd3f9.png` (look at this first)
- native 48px: `png/rod of asclepius_3726d96a-f376-4f85-be5e-b05615cdd3f9@48.png`
- tags: serpent, staff, asclepius, medicine, snake, symbol
- family: solo — author with `$icon-solo`
- proposed icon_id: `single-serpent-around-a-staff`

- source UUID: `3726d96a-f376-4f85-be5e-b05615cdd3f9`

## Description

A single snake winds around a thin upright staff in several broad curves that taper downward. The staff has a rounded knob at the top and extends below the final turn of the serpent.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
