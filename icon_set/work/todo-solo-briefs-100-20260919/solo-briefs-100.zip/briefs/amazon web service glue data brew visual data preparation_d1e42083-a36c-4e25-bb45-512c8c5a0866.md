# Data Shapes Flowing to the Right

- source: `pictographic-primitives/_uncategorized_02/amazon web service glue data brew visual data preparation_d1e42083-a36c-4e25-bb45-512c8c5a0866.svg`
- render: `png/amazon web service glue data brew visual data preparation_d1e42083-a36c-4e25-bb45-512c8c5a0866.png` (look at this first)
- native 48px: `png/amazon web service glue data brew visual data preparation_d1e42083-a36c-4e25-bb45-512c8c5a0866@48.png`
- tags: data, flow, shapes, arrows, conversion, circles, blocks
- family: solo — author with `$icon-solo`
- proposed icon_id: `data-shapes-flowing-to-the-right`

- source UUID: `d1e42083-a36c-4e25-bb45-512c8c5a0866`

## Description

Three small circles occupy a curved opening on the left. A sweeping lower arrow and a shorter upper arrow lead toward two upright rounded blocks on the right.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
