# Antenna Wired to a House

- source: `pictographic-primitives/_uncategorized_03/antenna house connect_b09ea8cd-dd09-438f-a30a-a49249a5dfc7.svg`
- render: `png/antenna house connect_b09ea8cd-dd09-438f-a30a-a49249a5dfc7.png` (look at this first)
- native 48px: `png/antenna house connect_b09ea8cd-dd09-438f-a30a-a49249a5dfc7@48.png`
- tags: antenna, house, cable, connection, signal, network, wireless
- family: solo — author with `$icon-solo`
- proposed icon_id: `antenna-wired-to-a-house`

- source UUID: `b09ea8cd-dd09-438f-a30a-a49249a5dfc7`

## Description

A triangular antenna tower with internal bracing stands to the left of a small pitched-roof house. A U-shaped cable connects their bases, and two signal arcs rise above the tower.

## To author

Run `$icon-solo`, which reads `icon_set/skills/icon-design/SKILL.md`, then the reference-backed
intake. Look at the render before choosing anything: name the subject in
one sentence, keep only what survives at native size, choose the keyshape,
and design backwards from its four extreme coordinates.

The reference sets the subject, not the grid, the stroke or the
proportions. Fit the result to the requested profile.

You can try modifying a copy of the SVG reference to fit the icon design rules,
or generate a new icon that matches the icon name. Either approach must follow
the requested family's design rules and preserve the named subject's identity.
Keep the original reference unchanged and produce the family skill's required deliverables.

## Fit the icon design rules

This reference is drawn at illustration scale — thin strokes and more
detail than a 48px canvas can hold. Adapt or regenerate it to fit:
fewer parts, the profile's stroke weight, larger gaps, geometry rebuilt on
the grid. Keep the meaning intact — the silhouette it is recognized by and
the parts that make it this subject and not a neighbouring one. Simplify
the drawing, never the meaning.
