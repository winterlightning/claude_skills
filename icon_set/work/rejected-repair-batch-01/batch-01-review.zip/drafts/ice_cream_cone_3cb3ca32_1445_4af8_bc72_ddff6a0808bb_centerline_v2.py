"""Make the ice-cream cone taller and broader at its shoulder; replace the skinny wedge with a stronger centered cone silhouette.
Independent centerline revision; original snapshot preserved."""
from ...keyshapes import Keyshape
from ._base import Solo48
SOURCE_ICON_ID = '3cb3ca32-1445-4af8-bc72-ddff6a0808bb'
SOURCE_PATH = 'pictographic-primitives/symbol/ice scream_3cb3ca32-1445-4af8-bc72-ddff6a0808bb.svg'
AUTHOR = 'gpt-6'

class IceCreamCone(Solo48):
    icon_id = 'ice-cream-cone-centerline-v2'
    keyshape = Keyshape.VRECT_L
    semantic_role = 'MAIN'
    semantic_kind = 'noun'
    category = 'objects/symbols'
    aliases = ()
    keywords = ('ice-cream', 'cone', 'dessert', 'sweet', 'summer', 'treat', 'gelato', 'food')

    def build(self) -> None:
        self.add_arc('scoop-top', (14, 14), (34, 14), radius_x=10)
        self.add_arc('scoop-right', (34, 14), (34, 28), radius_x=6, radius_y=7)
        self.add_arc('scallop-right', (34, 28), (24, 26), radius_x=8, radius_y=6)
        self.add_arc('scallop-left', (24, 26), (14, 28), radius_x=8, radius_y=6)
        self.add_arc('scoop-left', (14, 28), (14, 14), radius_x=6, radius_y=7)
        self.add_contour('scoop', 'scoop-top', 'scoop-right', 'scallop-right', 'scallop-left', 'scoop-left', closed=True)
        self.add_polyline('cone', (12, 27), (24, 44), (36, 27))
        self.relate('connect', 'scoop', 'cone')
    variant_of = 'ice-cream-cone'
    variant_label = 'Batch 01 centerline repair'
